import { GoogleGenAI } from '@google/genai';

export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Nur POST wird unterstützt.' });
  }
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return res.status(500).json({ error: 'GEMINI_API_KEY fehlt in den Vercel-Umgebungsvariablen.' });
  try {
    const prompt = typeof req.body?.prompt === 'string' ? req.body.prompt.trim() : '';
    if (!prompt) return res.status(400).json({ error: 'Bitte beschreibe das Bild.' });
    if (prompt.length > 1500) return res.status(400).json({ error: 'Die Beschreibung darf höchstens 1500 Zeichen haben.' });
    const ai = new GoogleGenAI({ apiKey });
    const result = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: prompt,
      config: { responseModalities: ['TEXT', 'IMAGE'] }
    });
    const parts = result.candidates?.[0]?.content?.parts || [];
    const imagePart = parts.find(p => p.inlineData?.data && p.inlineData?.mimeType?.startsWith('image/'));
    if (!imagePart) {
      const explanation = parts.find(p => p.text)?.text;
      return res.status(502).json({ error: explanation || 'Das Modell hat kein Bild zurückgegeben. Prüfe Modellzugriff und API-Kontingent.' });
    }
    return res.status(200).json({ image: `data:${imagePart.inlineData.mimeType};base64,${imagePart.inlineData.data}` });
  } catch (err) {
    console.error('Image generation failed:', err?.message || err);
    return res.status(500).json({ error: 'Bild konnte nicht erstellt werden. Prüfe API-Zugriff, Abrechnung und Kontingent in Google AI Studio.' });
  }
}
