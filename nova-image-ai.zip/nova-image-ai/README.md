# Nova AI – nur Bildgenerierung

## Projekt
- `index.html`: mobile Oberfläche für iPhone
- `api/generate.js`: serverseitiger Vercel-Endpunkt, der das Bildmodell aufruft
- `package.json`: Abhängigkeiten

## Auf Vercel veröffentlichen
1. Lade den Inhalt dieses Ordners in ein privates oder öffentliches GitHub-Repository hoch.
2. Öffne https://vercel.com/new und importiere das Repository.
3. Vercel erkennt das Node-Projekt; deploye es.
4. In Vercel: Project → Settings → Environment Variables. Füge `GEMINI_API_KEY` als Environment Variable hinzu und füge den neu erstellten Schlüssel aus Google AI Studio als Wert ein. Niemals den Schlüssel in `index.html`, GitHub oder Chat schreiben.
5. Redeploye die Website, damit die Variable verfügbar ist.
6. Öffne die Vercel-URL auf dem iPhone.

## Sicherheit und Limits
- Falls ein früherer Gemini-Schlüssel in einem Chat oder öffentlichen Code geteilt wurde, widerrufe ihn und erstelle einen neuen.
- Keine API-Schlüssel im Frontend.
- Bildmodell-/API-Verfügbarkeit, kostenloses Kontingent und Limits können sich ändern. Prüfe Google AI Studio vor dem Einsatz; keine unbegrenzte Gratisnutzung zugesichert.
- Dieser Starter generiert Bilder aus Text. Er speichert keine Galerie dauerhaft und bearbeitet noch keine hochgeladenen Fotos.
